"""Version information for ModelMan."""

__version__ = "0.1.0"