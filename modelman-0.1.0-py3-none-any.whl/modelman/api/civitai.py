"""CivitAI API integration for ModelMan."""
import logging
import time
from typing import Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


class CivitAILookup:
    """CivitAI API integration for external model lookup."""
    
    def __init__(self, enable_api: bool = True):
        """
        Initialize CivitAI API client.
        
        Args:
            enable_api: Whether to enable API calls
        """
        self.enable_api = enable_api
        self.base_url = "https://civitai.com/api/v1"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'ModelMan/1.0 (https://github.com/your-org/modelman)'
        })
        self.rate_limit_delay = 1.0
        self.last_request_time = 0
    
    def lookup_by_hash(self, file_hash: str) -> Dict:
        """
        Look up model by SHA-256 hash.
        
        Args:
            file_hash: SHA-256 hash of the model file (full file hash)
            
        Returns:
            Dictionary with lookup results
        """
        if not self.enable_api:
            return {'found': False, 'source': 'api_disabled'}
        
        try:
            # Rate limiting
            elapsed = time.time() - self.last_request_time
            if elapsed < self.rate_limit_delay:
                time.sleep(self.rate_limit_delay - elapsed)
            
            url = f"{self.base_url}/model-versions/by-hash/{file_hash}"
            response = self.session.get(url, timeout=10)
            self.last_request_time = time.time()
            
            if response.status_code == 200:
                data = response.json()
                return self.parse_civitai_response(data)
            elif response.status_code == 404:
                return {'found': False, 'source': 'civitai_not_found'}
            else:
                logger.warning(f"CivitAI API returned {response.status_code}")
                return {'found': False, 'source': f'civitai_error_{response.status_code}'}
                
        except Exception as e:
            logger.error(f"CivitAI API error: {e}")
            return {'found': False, 'source': f'civitai_exception_{type(e).__name__}'}
    
    def parse_civitai_response(self, data: Dict) -> Dict:
        """
        Parse CivitAI API response into ModelMan format.
        
        Args:
            data: Raw API response
            
        Returns:
            Parsed model information
        """
        try:
            model_info = data.get('model', {})
            version_info = data
            
            # Extract basic info
            name = model_info.get('name', 'Unknown')
            model_type = model_info.get('type', 'unknown').lower()
            
            # Map CivitAI types to ModelMan types
            type_mapping = {
                'checkpoint': 'main',
                'textualinversion': 'embedding',
                'lora': 'lora',
                'lycoris': 'lora',
                'hypernetwork': 'hypernetwork',
                'controlnet': 'controlnet',
                'vae': 'vae',
                'poses': 'pose',
                'wildcards': 'wildcard',
                'workflows': 'workflow',
                'other': 'unknown'
            }
            
            primary_type = type_mapping.get(model_type, 'unknown')
            base_model = self.extract_base_model(model_info, version_info)
            triggers = self.extract_civitai_triggers(version_info)
            
            # Generate human-readable URLs  
            # Note: API response has modelId at top level, not model.id
            civitai_id = version_info.get('modelId')  # This is the model ID
            version_id = version_info.get('id')       # This is the version ID
            
            model_url = f"https://civitai.com/models/{civitai_id}" if civitai_id else None
            version_url = f"https://civitai.com/models/{civitai_id}?modelVersionId={version_id}" if civitai_id and version_id else None
            
            return {
                'found': True,
                'source': 'civitai_api',
                'name': name,
                'model_type': primary_type,
                'base_model': base_model,
                'triggers': triggers,
                'confidence': 0.95,  # High confidence for CivitAI data
                'civitai_id': civitai_id,
                'version_id': version_id,
                'description': model_info.get('description', ''),
                'tags': model_info.get('tags', []),
                'nsfw': model_info.get('nsfw', False),
                # Human-readable URLs
                'model_url': model_url,
                'version_url': version_url,
                'raw_response': data  # Include complete raw response
            }
            
        except Exception as e:
            logger.error(f"CivitAI response parsing error: {e}")
            return {'found': False, 'source': f'civitai_parse_error_{type(e).__name__}'}
    
    def extract_base_model(self, model_info: Dict, version_info: Dict) -> str:
        """
        Extract base model from CivitAI data.
        
        Args:
            model_info: Model information from API
            version_info: Version information from API
            
        Returns:
            Base model identifier
        """
        base_model = version_info.get('baseModel', '')
        base_model_lower = base_model.lower()
        
        # Check base model field first - preserve detailed variants
        if 'flux.1 d' in base_model_lower or 'flux.1-d' in base_model_lower:
            return 'flux'
        elif 'flux.1 s' in base_model_lower or 'flux.1-s' in base_model_lower:
            return 'flux'
        elif 'flux' in base_model_lower:
            return 'flux'
        elif 'sdxl' in base_model_lower or 'xl' in base_model_lower:
            return 'sdxl'
        elif 'sd 3' in base_model_lower or 'sd3' in base_model_lower:
            return 'sd-3'
        elif 'sd 1.5' in base_model_lower or 'sd15' in base_model_lower:
            return 'sd-1'
        elif 'sd 2' in base_model_lower or 'sd2' in base_model_lower:
            return 'sd-2'
        elif 'pony' in base_model_lower:
            return 'sdxl'  # Pony is SDXL-based
        
        # Check model name for additional patterns
        name = model_info.get('name', '').lower()
        if 'flux' in name:
            return 'flux'
        elif 'xl' in name or 'sdxl' in name:
            return 'sdxl'
        elif 'sd3' in name:
            return 'sd-3'
        elif 'pony' in name:
            return 'sdxl'
        
        return base_model if base_model else 'unknown'
    
    def extract_civitai_triggers(self, version_info: Dict) -> List[str]:
        """
        Extract trigger words from CivitAI version info.
        
        Args:
            version_info: Version information from API
            
        Returns:
            List of trigger words
        """
        triggers = []
        
        # Check trainedWords field
        trained_words = version_info.get('trainedWords', [])
        if isinstance(trained_words, list):
            triggers.extend(trained_words)
        
        return triggers
    
    def search_models(self, query: str, limit: int = 10, types: Optional[List[str]] = None) -> Dict:
        """
        Search CivitAI models by name or description.
        
        Args:
            query: Search query
            limit: Maximum number of results
            types: Filter by model types
            
        Returns:
            Search results
        """
        if not self.enable_api:
            return {'found': False, 'source': 'api_disabled'}
        
        try:
            # Rate limiting
            elapsed = time.time() - self.last_request_time
            if elapsed < self.rate_limit_delay:
                time.sleep(self.rate_limit_delay - elapsed)
            
            params = {
                'query': query,
                'limit': limit
            }
            
            if types:
                params['types'] = types
            
            url = f"{self.base_url}/models"
            response = self.session.get(url, params=params, timeout=10)
            self.last_request_time = time.time()
            
            if response.status_code == 200:
                data = response.json()
                return {
                    'found': True,
                    'source': 'civitai_search',
                    'results': data.get('items', []),
                    'metadata': data.get('metadata', {})
                }
            else:
                logger.warning(f"CivitAI search returned {response.status_code}")
                return {'found': False, 'source': f'civitai_search_error_{response.status_code}'}
                
        except Exception as e:
            logger.error(f"CivitAI search error: {e}")
            return {'found': False, 'source': f'civitai_search_exception_{type(e).__name__}'}