"""Advanced model classification logic using InvokeAI's probing system."""
import logging
import uuid
from pathlib import Path
from typing import Union, Optional

from .exceptions import (
    ModelManException,
    UnsupportedFormatError, 
    FileAccessError,
    CorruptedModelError,
    ClassificationError,
)
from .hash import compute_blake3_hash, compute_civitai_hash, compute_sha256_hash
from .api import CivitAILookup
from .models import (
    ClassificationStatus,
    ModelClassificationResult,
)
from .probes.base import create_model_probe
from .utils.style_detection import detect_model_style

# Set up logging
logger = logging.getLogger(__name__)


def classify_model_advanced(
    file_path: Union[str, Path],
    compute_civitai_hash_flag: bool = True,
    hash_algorithm: str = "blake3_single",
    enable_civitai_lookup: bool = True
) -> ModelClassificationResult:
    """
    Classify a model file using advanced InvokeAI-based probing system.
    
    Args:
        file_path: Path to the model file or directory
        compute_civitai_hash_flag: Whether to compute CivitAI AutoV2 hash
        hash_algorithm: Hash algorithm to use (currently only blake3_single supported)
        enable_civitai_lookup: Whether to perform CivitAI API lookup
        
    Returns:
        ModelClassificationResult object with classification results
    """
    file_path = Path(file_path)
    
    # Initialize result with file info
    result = ModelClassificationResult(
        status=ClassificationStatus.ERROR,
        file_path=str(file_path.absolute()),
        file_name=file_path.name,
        file_size=0,
        key=str(uuid.uuid4()),
    )
    
    try:
        # Basic file validation
        if not file_path.exists():
            result.error_type = "FileNotFoundError"
            result.error_message = f"File or directory not found: {file_path}"
            return result
        
        # Get file size
        if file_path.is_file():
            result.file_size = file_path.stat().st_size
        elif file_path.is_dir():
            result.file_size = sum(f.stat().st_size for f in file_path.rglob("*") if f.is_file())
        else:
            result.error_type = "InvalidPathError"
            result.error_message = f"Path is neither file nor directory: {file_path}"
            return result
        
        # Create appropriate probe
        probe = create_model_probe(file_path)
        if probe is None:
            result.status = ClassificationStatus.UNSUPPORTED
            result.error_type = "UnsupportedFormatError"
            if file_path.is_file():
                ext = file_path.suffix.lower()
                result.error_message = f"File extension '{ext}' is not a supported model format"
            else:
                result.error_message = f"Directory does not contain recognizable model format"
            return result
        
        # Compute hashes
        try:
            logger.info(f"Computing Blake3 hash for {file_path}")
            result.hash_blake3 = compute_blake3_hash(file_path)
            
            if compute_civitai_hash_flag and file_path.is_file():
                logger.info(f"Computing CivitAI AutoV2 hash for {file_path}")
                result.hash_civitai = compute_civitai_hash(file_path)
            
            # Compute SHA-256 for CivitAI API lookup
            if enable_civitai_lookup and file_path.is_file():
                logger.info(f"Computing SHA-256 hash for {file_path}")
                result.hash_sha256 = compute_sha256_hash(file_path)
        except Exception as e:
            logger.warning(f"Hash computation failed: {e}")
            # Continue without hashes - classification may still work
        
        # Perform advanced model classification using probe
        try:
            # Get basic classification
            result.model_format = probe.get_format()
            result.model_type = probe.get_model_type()
            result.base_model = probe.get_base_type()
            result.model_variant = probe.get_variant_type()
            result.prediction_type = probe.get_scheduler_prediction_type()
            
            # Get additional metadata
            image_encoder_id = probe.get_image_encoder_model_id()
            if image_encoder_id:
                result.raw_config = {"image_encoder_model_id": image_encoder_id}
            
            submodels = probe.get_submodels()
            if submodels:
                result.submodels = submodels
            
            # Determine config path for checkpoint models
            if result.model_format == "checkpoint" and result.base_model:
                result.config_path = _get_checkpoint_config_path(result.base_model, result.model_variant)
            
            result.status = ClassificationStatus.SUCCESS
            
            # Detect model style from filename and metadata
            result.model_style = detect_model_style(file_path, result.file_name)
            
            # CivitAI API lookup
            if enable_civitai_lookup and result.hash_sha256:
                try:
                    logger.info(f"Looking up model in CivitAI database")
                    civitai = CivitAILookup()
                    civitai_result = civitai.lookup_by_hash(result.hash_sha256)
                    
                    if civitai_result.get('found'):
                        result.civitai_info = civitai_result
                        logger.info(f"CivitAI: Found model '{civitai_result.get('name', 'Unknown')}'")
                        
                        # Optionally override classification with CivitAI data for better accuracy
                        if civitai_result.get('model_type') and civitai_result.get('model_type') != 'unknown':
                            result.model_type = civitai_result['model_type']
                        if civitai_result.get('base_model') and civitai_result.get('base_model') != 'unknown':
                            result.base_model = civitai_result['base_model']
                    else:
                        logger.debug(f"CivitAI: Model not found in database")
                except Exception as e:
                    logger.warning(f"CivitAI lookup failed: {e}")
                    # Continue without CivitAI data
            
            # Generate description
            if result.model_type and result.base_model:
                style_part = f" ({result.model_style})" if result.model_style and result.model_style != "unknown" else ""
                civitai_name = ""
                if result.civitai_info and result.civitai_info.get('name'):
                    civitai_name = f" [{result.civitai_info['name']}]"
                result.description = f"{result.base_model} {result.model_type} model {result.file_name}{style_part}{civitai_name}"
            
        except Exception as e:
            logger.error(f"Advanced classification failed for {file_path}: {e}")
            result.error_type = type(e).__name__
            result.error_message = str(e)
            return result
            
    except FileAccessError as e:
        result.error_type = "FileAccessError"
        result.error_message = str(e)
    except CorruptedModelError as e:
        result.error_type = "CorruptedModelError" 
        result.error_message = str(e)
    except Exception as e:
        logger.exception(f"Unexpected error classifying {file_path}")
        result.error_type = type(e).__name__
        result.error_message = f"Unexpected error: {str(e)}"
    
    return result


def _get_checkpoint_config_path(base_model: str, variant: str) -> Optional[str]:
    """
    Get the appropriate config file path for a checkpoint model.
    
    Args:
        base_model: Base model type (sd-1, sdxl, etc.)
        variant: Model variant (normal, inpaint, etc.)
        
    Returns:
        Relative path to config file
    """
    config_map = {
        "sd-1": {
            "normal": "stable-diffusion/v1-inference.yaml",
            "inpaint": "stable-diffusion/v1-inpainting-inference.yaml",
        },
        "sd-2": {
            "normal": "stable-diffusion/v2-inference.yaml",
            "inpaint": "stable-diffusion/v2-inpainting-inference.yaml",
        },
        "sdxl": {
            "normal": "stable-diffusion/sd_xl_base.yaml",
            "inpaint": "stable-diffusion/sd_xl_inpaint.yaml",
        },
        "sdxl-refiner": {
            "normal": "stable-diffusion/sd_xl_refiner.yaml",
        },
    }
    
    base_configs = config_map.get(base_model, {})
    return base_configs.get(variant or "normal")


# Backwards compatibility - use advanced classifier as default
classify_model = classify_model_advanced