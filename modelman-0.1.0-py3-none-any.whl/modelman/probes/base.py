"""Base classes for model probing system."""
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Optional, Any

logger = logging.getLogger(__name__)


class ModelProbeBase(ABC):
    """Base class for model probes."""
    
    def __init__(self, model_path: Path):
        self.model_path = model_path
        
    @abstractmethod
    def get_model_type(self) -> Optional[str]:
        """Get the model type (main, lora, controlnet, etc.)."""
        pass
    
    @abstractmethod
    def get_base_type(self) -> Optional[str]:
        """Get the base model type (sd-1, sdxl, flux, etc.)."""
        pass
    
    @abstractmethod
    def get_format(self) -> Optional[str]:
        """Get the model format (checkpoint, diffusers, etc.)."""
        pass
    
    def get_variant_type(self) -> Optional[str]:
        """Get the model variant (normal, inpaint, depth, etc.)."""
        return "normal"
    
    def get_scheduler_prediction_type(self) -> Optional[str]:
        """Get the scheduler prediction type."""
        return "epsilon"
    
    def get_image_encoder_model_id(self) -> Optional[str]:
        """Get the image encoder model ID (for IP adapters, etc.)."""
        return None
    
    def get_submodels(self) -> Optional[Dict[str, Any]]:
        """Get submodel definitions for composite models."""
        return None


class CheckpointProbe(ModelProbeBase):
    """Probe for checkpoint format models (.safetensors, .ckpt, etc.)."""
    
    def __init__(self, model_path: Path):
        super().__init__(model_path)
        self._checkpoint = None
        self._analyzed = False
        
    @property
    def checkpoint(self) -> Optional[Dict[str, Any]]:
        """Lazy-load checkpoint metadata."""
        if self._checkpoint is None and not self._analyzed:
            self._analyzed = True
            try:
                from ..utils.model_util import read_checkpoint_meta
                self._checkpoint = read_checkpoint_meta(self.model_path)
                logger.debug(f"Loaded checkpoint metadata for {self.model_path}")
            except Exception as e:
                logger.error(f"Failed to load checkpoint {self.model_path}: {e}")
                self._checkpoint = {}
        return self._checkpoint
    
    def get_format(self) -> Optional[str]:
        """Get checkpoint format."""
        suffix = self.model_path.suffix.lower()
        if suffix in [".safetensors"]:
            return "checkpoint"
        elif suffix in [".ckpt", ".pt", ".pth", ".bin"]:
            return "checkpoint"
        elif suffix == ".gguf":
            return "gguf_quantized"
        elif suffix == ".onnx":
            return "onnx"
        return "unknown"
    
    def get_model_type(self) -> Optional[str]:
        """Determine model type from checkpoint analysis."""
        if not self.checkpoint:
            return None
            
        from ..utils.model_util import get_model_type_from_checkpoint_keys
        return get_model_type_from_checkpoint_keys(self.checkpoint)
    
    def get_base_type(self) -> Optional[str]:
        """Determine base model type from checkpoint analysis."""
        if not self.checkpoint:
            return None
            
        from ..utils.model_util import get_base_model_from_checkpoint_keys
        return get_base_model_from_checkpoint_keys(self.checkpoint)


class DiffusersProbe(ModelProbeBase):
    """Probe for diffusers format models (directories)."""
    
    def __init__(self, model_path: Path):
        super().__init__(model_path)
        self._model_info = None
        self._analyzed = False
        
    @property
    def model_info(self) -> Optional[Dict[str, Any]]:
        """Lazy-load diffusers model info."""
        if self._model_info is None and not self._analyzed:
            self._analyzed = True
            try:
                from ..utils.diffusers_util import get_diffusers_model_info
                self._model_info = get_diffusers_model_info(self.model_path)
                logger.debug(f"Loaded diffusers model info for {self.model_path}")
            except Exception as e:
                logger.error(f"Failed to analyze diffusers model {self.model_path}: {e}")
                self._model_info = {}
        return self._model_info
    
    def get_format(self) -> Optional[str]:
        """Get diffusers format."""
        return "diffusers"
    
    def get_model_type(self) -> Optional[str]:
        """Get model type from diffusers info."""
        if not self.model_info:
            return None
        return self.model_info.get("model_type")
    
    def get_base_type(self) -> Optional[str]:
        """Get base model type from diffusers info."""
        if not self.model_info:
            return None
        return self.model_info.get("base_model")
    
    def get_variant_type(self) -> Optional[str]:
        """Get variant type from diffusers model."""
        if not self.model_info:
            return "normal"
            
        try:
            from ..utils.diffusers_util import get_diffusers_variant_type
            return get_diffusers_variant_type(self.model_path, self.model_info) or "normal"
        except Exception as e:
            logger.debug(f"Failed to get variant type: {e}")
            return "normal"
    
    def get_submodels(self) -> Optional[Dict[str, Any]]:
        """Get submodel definitions."""
        if not self.model_info:
            return None
        return self.model_info.get("submodels")


def create_model_probe(model_path: Path) -> Optional[ModelProbeBase]:
    """
    Factory function to create appropriate probe for a model.
    
    Args:
        model_path: Path to model file or directory
        
    Returns:
        Appropriate probe instance or None if unsupported
    """
    if not model_path.exists():
        return None
    
    if model_path.is_file():
        # Checkpoint format
        supported_extensions = {".safetensors", ".ckpt", ".pt", ".pth", ".bin", ".gguf", ".onnx"}
        if model_path.suffix.lower() in supported_extensions:
            return CheckpointProbe(model_path)
    elif model_path.is_dir():
        # Check for diffusers format
        from ..utils.diffusers_util import is_diffusers_model
        if is_diffusers_model(model_path):
            return DiffusersProbe(model_path)
    
    return None