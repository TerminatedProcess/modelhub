"""ModelMan: AI model classification library."""
from .classifier_advanced import classify_model
from .models import (
    ClassificationStatus,
    ModelClassificationResult,
    BaseModelType,
    ModelType,
    ModelFormat,
    ModelVariantType,
    ModelStyleType,
)
from .version import __version__

__all__ = [
    # Main API
    "classify_model",
    # Result classes
    "ClassificationStatus", 
    "ModelClassificationResult",
    # Common enums
    "BaseModelType",
    "ModelType",
    "ModelFormat", 
    "ModelVariantType",
    "ModelStyleType",
    # Version
    "__version__",
]