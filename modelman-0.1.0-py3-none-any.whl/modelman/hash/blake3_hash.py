"""Blake3 hash implementation based on InvokeAI's approach."""
import os
from pathlib import Path
from typing import Callable, List, Union

try:
    from blake3 import blake3
    BLAKE3_AVAILABLE = True
except ImportError:
    BLAKE3_AVAILABLE = False
    blake3 = None


def compute_blake3_hash(file_path: Union[str, Path]) -> str:
    """
    Compute Blake3 hash for a model file or directory.
    
    For single files, computes hash directly.
    For directories, hashes all model files and creates composite hash.
    
    Args:
        file_path: Path to model file or directory
        
    Returns:
        Hexdigest of the Blake3 hash (no prefix)
        
    Raises:
        FileNotFoundError: If file/directory doesn't exist
        IOError: If file cannot be read
    """
    if not BLAKE3_AVAILABLE:
        raise ImportError("blake3 package not available - install with: pip install blake3")
    
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Model file/directory not found: {file_path}")
    
    if file_path.is_file():
        return _hash_file(file_path)
    elif file_path.is_dir():
        return _hash_directory(file_path)
    else:
        raise ValueError(f"Path is neither file nor directory: {file_path}")


def _hash_file(file_path: Path) -> str:
    """Hash a single file using Blake3."""
    hasher = blake3()
    
    try:
        # Use memory mapping for efficiency (like InvokeAI)
        hasher.update_mmap(file_path)
        return hasher.hexdigest()
    except Exception:
        # Fallback to regular file reading if mmap fails
        return _hash_file_fallback(file_path)


def _hash_file_fallback(file_path: Path) -> str:
    """Fallback file hashing using regular file I/O."""
    hasher = blake3()
    buffer = bytearray(128 * 1024)  # 128KB buffer
    mv = memoryview(buffer)
    
    with open(file_path, "rb", buffering=0) as f:
        while True:
            n = f.readinto(mv)
            if not n:
                break
            hasher.update(mv[:n])
    
    return hasher.hexdigest()


def _hash_directory(dir_path: Path) -> str:
    """Hash all model files in a directory."""
    model_files = _get_model_files(dir_path)
    
    if not model_files:
        # Empty directory or no model files
        return blake3(b"").hexdigest()
    
    # Hash each file and combine
    component_hashes: List[str] = []
    for file_path in sorted(model_files):
        file_hash = _hash_file(file_path)
        component_hashes.append(file_hash)
    
    # Create composite hash using Blake3 (like InvokeAI)
    composite_hasher = blake3()
    for hash_str in component_hashes:
        composite_hasher.update(hash_str.encode("utf-8"))
    
    return composite_hasher.hexdigest()


def _get_model_files(dir_path: Path) -> List[Path]:
    """Get all model files in a directory recursively."""
    model_extensions = (".ckpt", ".safetensors", ".bin", ".pt", ".pth", ".gguf")
    model_files: List[Path] = []
    
    for root, _dirs, files in os.walk(dir_path):
        for file in files:
            if any(file.lower().endswith(ext) for ext in model_extensions):
                model_files.append(Path(root) / file)
    
    return model_files