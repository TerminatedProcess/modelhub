"""Full SHA-256 hash implementation for CivitAI API compatibility."""
import hashlib
from pathlib import Path
from typing import Union


def compute_sha256_hash(file_path: Union[str, Path]) -> str:
    """
    Compute full SHA-256 hash of a file for CivitAI API lookups.
    
    This computes the hash of the entire file, which is what CivitAI uses
    for their model lookup API, unlike the AutoV2 algorithm which only
    hashes the first and last 8KB.
    
    Args:
        file_path: Path to the file
        
    Returns:
        Uppercase hex string of the SHA-256 hash
        
    Raises:
        FileNotFoundError: If file doesn't exist
        IOError: If file cannot be read
    """
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
    
    if not file_path.is_file():
        raise ValueError(f"Path is not a file: {file_path}")
    
    # Compute full SHA-256 hash
    hash_sha256 = hashlib.sha256()
    
    with open(file_path, "rb") as f:
        # Read in chunks to handle large files efficiently
        for chunk in iter(lambda: f.read(65536), b""):  # 64KB chunks
            hash_sha256.update(chunk)
    
    # Return uppercase hex string (CivitAI format)
    return hash_sha256.hexdigest().upper()