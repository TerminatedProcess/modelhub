"""CivitAI AutoV2 hash implementation."""
import hashlib
from pathlib import Path
from typing import Union


def compute_civitai_hash(file_path: Union[str, Path]) -> str:
    """
    Compute CivitAI AutoV2 hash for a model file.
    
    CivitAI uses AutoV2 hash which is SHA256 of the first and last 8192 bytes.
    This is much faster than hashing the entire file.
    
    Args:
        file_path: Path to the model file
        
    Returns:
        Uppercase hex string of the AutoV2 hash
        
    Raises:
        FileNotFoundError: If file doesn't exist
        IOError: If file cannot be read
    """
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f"Model file not found: {file_path}")
    
    if not file_path.is_file():
        raise ValueError(f"Path is not a file: {file_path}")
    
    file_size = file_path.stat().st_size
    
    # CivitAI AutoV2 algorithm: SHA256 of first and last 8192 bytes
    chunk_size = 8192
    
    with open(file_path, "rb") as f:
        # Read first chunk
        first_chunk = f.read(chunk_size)
        
        if file_size <= chunk_size:
            # Small file - hash the entire content
            hash_data = first_chunk
        else:
            # Large file - read last chunk
            f.seek(file_size - chunk_size)
            last_chunk = f.read(chunk_size)
            hash_data = first_chunk + last_chunk
    
    # Compute SHA256 hash
    sha256_hash = hashlib.sha256(hash_data).hexdigest()
    
    # Return uppercase hex string (CivitAI format)
    return sha256_hash.upper()