"""Main model classification logic for ModelMan."""
import logging
import uuid
from pathlib import Path
from typing import Union, Optional

from .exceptions import (
    ModelManException,
    UnsupportedFormatError, 
    FileAccessError,
    CorruptedModelError,
    ClassificationError,
)
from .hash import compute_blake3_hash, compute_civitai_hash
from .models import (
    ClassificationStatus,
    ModelClassificationResult,
    ModelFormat,
    ModelType,
)

# Set up logging
logger = logging.getLogger(__name__)


def classify_model(
    file_path: Union[str, Path],
    compute_civitai_hash_flag: bool = True,
    hash_algorithm: str = "blake3_single"
) -> ModelClassificationResult:
    """
    Classify a model file and return comprehensive metadata.
    
    Args:
        file_path: Path to the model file or directory
        compute_civitai_hash_flag: Whether to compute CivitAI AutoV2 hash
        hash_algorithm: Hash algorithm to use (currently only blake3_single supported)
        
    Returns:
        ModelClassificationResult object with classification results
    """
    file_path = Path(file_path)
    
    # Initialize result with file info
    result = ModelClassificationResult(
        status=ClassificationStatus.ERROR,
        file_path=str(file_path.absolute()),
        file_name=file_path.name,
        file_size=0,
        key=str(uuid.uuid4()),
    )
    
    try:
        # Basic file validation
        if not file_path.exists():
            result.error_type = "FileNotFoundError"
            result.error_message = f"File or directory not found: {file_path}"
            return result
        
        # Get file size
        if file_path.is_file():
            result.file_size = file_path.stat().st_size
        elif file_path.is_dir():
            result.file_size = sum(f.stat().st_size for f in file_path.rglob("*") if f.is_file())
        else:
            result.error_type = "InvalidPathError"
            result.error_message = f"Path is neither file nor directory: {file_path}"
            return result
        
        # Check if format is supported
        if not _is_supported_format(file_path):
            result.status = ClassificationStatus.UNSUPPORTED
            result.error_type = "UnsupportedFormatError"
            if file_path.is_file():
                ext = file_path.suffix.lower()
                result.error_message = f"File extension '{ext}' is not a supported model format"
            else:
                result.error_message = f"Directory does not contain recognizable model format"
            return result
        
        # Compute hashes
        try:
            logger.info(f"Computing Blake3 hash for {file_path}")
            result.hash_blake3 = compute_blake3_hash(file_path)
            
            if compute_civitai_hash_flag and file_path.is_file():
                logger.info(f"Computing CivitAI hash for {file_path}")
                result.hash_civitai = compute_civitai_hash(file_path)
        except Exception as e:
            logger.warning(f"Hash computation failed: {e}")
            # Continue without hashes - classification may still work
        
        # Perform model classification
        try:
            _classify_model_type(file_path, result)
            result.status = ClassificationStatus.SUCCESS
            
            # Generate description
            if result.model_type and result.base_model:
                result.description = f"{result.base_model} {result.model_type} model {result.file_name}"
            
        except Exception as e:
            logger.error(f"Classification failed for {file_path}: {e}")
            result.error_type = type(e).__name__
            result.error_message = str(e)
            return result
            
    except FileAccessError as e:
        result.error_type = "FileAccessError"
        result.error_message = str(e)
    except CorruptedModelError as e:
        result.error_type = "CorruptedModelError" 
        result.error_message = str(e)
    except Exception as e:
        logger.exception(f"Unexpected error classifying {file_path}")
        result.error_type = type(e).__name__
        result.error_message = f"Unexpected error: {str(e)}"
    
    return result


def _is_supported_format(file_path: Path) -> bool:
    """Check if the file format is supported for classification."""
    supported_extensions = {
        ".safetensors", ".ckpt", ".pt", ".pth", ".bin", ".gguf", ".onnx"
    }
    
    if file_path.is_file():
        return file_path.suffix.lower() in supported_extensions
    elif file_path.is_dir():
        # Check for diffusers format
        if (file_path / "model_index.json").exists():
            return True
        # Check for any supported model files
        for ext in supported_extensions:
            if any(file_path.glob(f"**/*{ext}")):
                return True
        return False
    
    return False


def _classify_model_type(file_path: Path, result: ModelClassificationResult) -> None:
    """
    Classify the model type and populate result fields.
    
    This is a simplified version that will be expanded with InvokeAI's
    classification logic in future iterations.
    """
    # Determine format
    if file_path.is_dir():
        if (file_path / "model_index.json").exists():
            result.model_format = ModelFormat.Diffusers.value
        else:
            result.model_format = "unknown_directory"
    else:
        ext = file_path.suffix.lower()
        if ext in [".safetensors", ".ckpt", ".pt", ".pth", ".bin"]:
            result.model_format = ModelFormat.Checkpoint.value
        elif ext == ".gguf":
            result.model_format = ModelFormat.GGUFQuantized.value
        elif ext == ".onnx":
            result.model_format = ModelFormat.ONNX.value
        else:
            result.model_format = "unknown"
    
    # Basic type classification (will be expanded)
    # For now, assume most single files are main models
    if file_path.is_file():
        file_name = file_path.name.lower()
        if "lora" in file_name or "lyco" in file_name:
            result.model_type = ModelType.LoRA.value
        elif "controlnet" in file_name:
            result.model_type = ModelType.ControlNet.value
        elif "vae" in file_name:
            result.model_type = ModelType.VAE.value
        elif "embedding" in file_name or "textual_inversion" in file_name:
            result.model_type = ModelType.TextualInversion.value
        else:
            result.model_type = ModelType.Main.value
    else:
        # Directory - assume main model for now
        result.model_type = ModelType.Main.value
    
    # Basic base model detection (simplified)
    if result.model_type == ModelType.Main.value:
        file_name = file_path.name.lower()
        if "xl" in file_name or "sdxl" in file_name:
            result.base_model = "sdxl"
        elif "flux" in file_name:
            result.base_model = "flux" 
        elif "sd3" in file_name or "sd_3" in file_name:
            result.base_model = "sd-3"
        elif "sd2" in file_name or "sd_2" in file_name or "v2" in file_name:
            result.base_model = "sd-2"
        else:
            result.base_model = "sd-1"  # Default assumption
    else:
        result.base_model = "unknown"
    
    # Default values
    result.model_variant = "normal"
    result.prediction_type = "epsilon"