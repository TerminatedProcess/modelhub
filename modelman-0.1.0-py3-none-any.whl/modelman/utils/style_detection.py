"""Style detection utilities for ModelMan."""
import logging
import re
from pathlib import Path
from typing import Optional

from ..models.taxonomy import ModelStyleType

logger = logging.getLogger(__name__)


def detect_model_style(file_path: str, model_name: Optional[str] = None) -> str:
    """
    Detect model style/aesthetic from filename and optional metadata.
    
    Args:
        file_path: Path to the model file
        model_name: Optional model name from metadata
        
    Returns:
        Detected style type
    """
    # Get filename for analysis
    filename = Path(file_path).stem.lower()
    
    # Optional model name from metadata
    metadata_name = (model_name or "").lower() if model_name else ""
    
    # Combined text for analysis
    text_to_analyze = f"{filename} {metadata_name}".strip()
    
    # Style detection patterns (order matters - more specific first)
    style_patterns = [
        # Specific model series
        (r'illustrous|illustrious', ModelStyleType.Illustrious),
        
        # Anime/Manga styles
        (r'\banime\b|\bmanga\b|\bwaifu\b|\botaku\b', ModelStyleType.Anime),
        
        # Cartoon/Toon styles  
        (r'\bcartoon\b|\btoon\b|\bcomics?\b|\banimated\b', ModelStyleType.Cartoon),
        
        # Realistic styles
        (r'\brealistic?\b|\bphoto\b|\breal\b', ModelStyleType.Realistic),
        (r'\bphotorealistic\b|\bphoto.?realistic\b', ModelStyleType.Photorealistic),
        
        # Artistic styles
        (r'\bartistic?\b|\bpainting\b|\bart\b|\bstyle\b', ModelStyleType.Artistic),
        
        # Fantasy themes
        (r'\bfantasy\b|\bmagic\b|\bmedieval\b|\belves?\b|\bdragons?\b', ModelStyleType.Fantasy),
        
        # Sci-fi themes
        (r'\bsci.?fi\b|\bscience.?fiction\b|\bfuture\b|\bspace\b|\brobot\b|\bcyber\b', ModelStyleType.SciFi),
        
        # Portrait focus
        (r'\bportrait\b|\bface\b|\bheadshot\b|\bpeople\b', ModelStyleType.Portrait),
        
        # Landscape focus
        (r'\blandscape\b|\bscenery\b|\bnature\b|\benvironment\b', ModelStyleType.Landscape),
    ]
    
    # Check patterns in order of specificity
    for pattern, style in style_patterns:
        if re.search(pattern, text_to_analyze):
            logger.debug(f"Detected style '{style}' from pattern '{pattern}' in '{text_to_analyze}'")
            return style.value
    
    # No specific style detected
    return ModelStyleType.Unknown.value


def detect_model_purpose(file_path: str, model_name: Optional[str] = None) -> Optional[str]:
    """
    Detect the intended purpose/use case of a model.
    
    Args:
        file_path: Path to the model file
        model_name: Optional model name from metadata
        
    Returns:
        Detected purpose or None
    """
    filename = Path(file_path).stem.lower()
    metadata_name = (model_name or "").lower() if model_name else ""
    text_to_analyze = f"{filename} {metadata_name}".strip()
    
    purpose_patterns = [
        (r'\bnsfw\b|\badult\b|\bexplicit\b', "adult_content"),
        (r'\bsfw\b|\bsafe\b|\bclean\b', "safe_content"),
        (r'\bcharacter\b|\bperson\b|\bpeople\b', "character_generation"),
        (r'\bobject\b|\bthing\b|\bitem\b', "object_generation"),
        (r'\bbackground\b|\bscene\b|\benvironment\b', "background_generation"),
        (r'\bconcept\b|\bstyle\b|\baesthetic\b', "style_transfer"),
    ]
    
    for pattern, purpose in purpose_patterns:
        if re.search(pattern, text_to_analyze):
            return purpose
    
    return None


def get_style_description(style: str) -> str:
    """
    Get a human-readable description of a style type.
    
    Args:
        style: Style type string
        
    Returns:
        Human-readable description
    """
    descriptions = {
        ModelStyleType.Unknown: "Style not detected or unknown",
        ModelStyleType.Realistic: "Realistic, lifelike imagery",
        ModelStyleType.Anime: "Anime/manga style artwork", 
        ModelStyleType.Illustrious: "Illustrious XL series - high-quality anime illustrations",
        ModelStyleType.Cartoon: "Cartoon/animated style imagery",
        ModelStyleType.Photorealistic: "Photorealistic, camera-like imagery",
        ModelStyleType.Artistic: "Artistic, painterly style",
        ModelStyleType.Fantasy: "Fantasy themes and elements",
        ModelStyleType.SciFi: "Science fiction themes and futuristic elements",
        ModelStyleType.Portrait: "Portrait and people-focused imagery",
        ModelStyleType.Landscape: "Landscape and environmental imagery",
    }
    
    return descriptions.get(style, f"Style: {style}")