"""Utilities for detecting and analyzing diffusers format models."""
import json
import logging
from pathlib import Path
from typing import Dict, Optional, Any

logger = logging.getLogger(__name__)


def is_diffusers_model(path: Path) -> bool:
    """
    Check if a directory contains a diffusers format model.
    
    Args:
        path: Path to directory to check
        
    Returns:
        True if directory contains diffusers model
    """
    if not path.is_dir():
        return False
    
    # Primary indicator: model_index.json
    model_index = path / "model_index.json"
    if model_index.exists():
        return True
    
    # Secondary indicators: common diffusers subdirectories
    diffusers_subdirs = {"unet", "vae", "text_encoder", "tokenizer", "scheduler"}
    existing_subdirs = {d.name for d in path.iterdir() if d.is_dir()}
    
    # If we have at least 2 diffusers subdirectories, likely a diffusers model
    return len(diffusers_subdirs.intersection(existing_subdirs)) >= 2


def get_diffusers_model_info(path: Path) -> Optional[Dict[str, Any]]:
    """
    Extract model information from diffusers format directory.
    
    Args:
        path: Path to diffusers model directory
        
    Returns:
        Dictionary with model information or None if invalid
    """
    if not is_diffusers_model(path):
        return None
    
    info = {
        "format": "diffusers",
        "model_type": None,
        "base_model": None,
        "submodels": {},
    }
    
    # Read model_index.json if available
    model_index = path / "model_index.json"
    if model_index.exists():
        try:
            with open(model_index) as f:
                index_data = json.load(f)
                
            # Extract class name to determine model type
            class_name = index_data.get("_class_name", "")
            info["class_name"] = class_name
            
            # Map class names to model types
            if "Pipeline" in class_name:
                info["model_type"] = "main"
                
                if "StableDiffusionPipeline" in class_name:
                    if "XL" in class_name:
                        info["base_model"] = "sdxl"
                    elif "3" in class_name:
                        info["base_model"] = "sd-3"
                    else:
                        info["base_model"] = "sd-1"  # or sd-2, needs more analysis
                elif "FluxPipeline" in class_name:
                    info["base_model"] = "flux"
                elif "XL" in class_name:  # Fallback for SDXL variants
                    info["base_model"] = "sdxl"
                    
            elif "AutoencoderKL" in class_name:
                info["model_type"] = "vae"
            
            # Extract submodel information
            for key, value in index_data.items():
                if key.startswith("_"):
                    continue
                if isinstance(value, list) and len(value) == 2:
                    # Format: [class_name, subfolder]
                    info["submodels"][key] = {
                        "class_name": value[0],
                        "subfolder": value[1] if value[1] else key
                    }
                    
        except Exception as e:
            logger.warning(f"Failed to read model_index.json from {path}: {e}")
    
    # Analyze subdirectories
    subdirs = [d for d in path.iterdir() if d.is_dir()]
    info["subdirectories"] = [d.name for d in subdirs]
    
    # Try to determine base model from config files if not already determined
    if not info["base_model"]:
        info["base_model"] = _detect_base_model_from_configs(path)
    
    return info


def _detect_base_model_from_configs(path: Path) -> Optional[str]:
    """
    Detect base model type from configuration files in subdirectories.
    
    Args:
        path: Path to diffusers model directory
        
    Returns:
        Detected base model type or None
    """
    # Check UNet config for cross-attention dimension
    unet_config = path / "unet" / "config.json"
    if unet_config.exists():
        try:
            with open(unet_config) as f:
                unet_data = json.load(f)
                
            cross_attention_dim = unet_data.get("cross_attention_dim")
            if isinstance(cross_attention_dim, list):
                cross_attention_dim = cross_attention_dim[0]
            
            if cross_attention_dim == 768:
                return "sd-1"
            elif cross_attention_dim == 1024:
                return "sd-2"
            elif cross_attention_dim == 2048:
                return "sdxl"
                
        except Exception as e:
            logger.debug(f"Failed to read unet config from {path}: {e}")
    
    # Check for transformer config (SD3/FLUX)
    transformer_config = path / "transformer" / "config.json"
    if transformer_config.exists():
        try:
            with open(transformer_config) as f:
                transformer_data = json.load(f)
                
            # Check for FLUX-specific parameters
            if "guidance_embed" in transformer_data or "time_text_embed" in transformer_data:
                return "flux"
            elif "pooled_projection_dim" in transformer_data:
                return "sd-3"
                
        except Exception as e:
            logger.debug(f"Failed to read transformer config from {path}: {e}")
    
    # Check text encoder config for additional hints
    text_encoder_config = path / "text_encoder" / "config.json"
    if text_encoder_config.exists():
        try:
            with open(text_encoder_config) as f:
                te_data = json.load(f)
                
            hidden_size = te_data.get("hidden_size")
            if hidden_size == 768:
                return "sd-1"
            elif hidden_size == 1024:
                return "sd-2"
            elif hidden_size == 1280:
                # Could be SDXL or other variants
                return "sdxl"
                
        except Exception as e:
            logger.debug(f"Failed to read text encoder config from {path}: {e}")
    
    return None


def get_diffusers_variant_type(path: Path, model_info: Dict[str, Any]) -> Optional[str]:
    """
    Determine model variant (normal, inpaint, depth) from diffusers model.
    
    Args:
        path: Path to diffusers model directory
        model_info: Model information from get_diffusers_model_info
        
    Returns:
        Variant type or None
    """
    # Check model index class name for variant hints
    class_name = model_info.get("class_name", "")
    
    if "Inpaint" in class_name:
        return "inpaint"
    elif "Depth" in class_name:
        return "depth"
    
    # Check UNet config for input channels (indicator of variant)
    unet_config = path / "unet" / "config.json"
    if unet_config.exists():
        try:
            with open(unet_config) as f:
                unet_data = json.load(f)
                
            in_channels = unet_data.get("in_channels", 4)
            
            # Standard models typically have 4 input channels
            # Inpaint models have 9 channels (4 + 4 + 1 for mask)
            if in_channels == 9:
                return "inpaint"
            elif in_channels == 5:  # Some depth models use 5 channels
                return "depth"
                
        except Exception as e:
            logger.debug(f"Failed to read unet config for variant detection: {e}")
    
    return "normal"