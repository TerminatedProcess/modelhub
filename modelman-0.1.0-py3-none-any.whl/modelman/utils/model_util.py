"""Utilities for parsing model files, adapted from InvokeAI."""
import json
import logging
from pathlib import Path
from typing import Dict, Optional, Union

import torch

logger = logging.getLogger(__name__)

# Optional imports for specialized formats
try:
    import safetensors.torch
    SAFETENSORS_AVAILABLE = True
except ImportError:
    SAFETENSORS_AVAILABLE = False
    logger.warning("safetensors not available - safetensors support disabled")

try:
    import picklescan.scanner as pscan
    PICKLESCAN_AVAILABLE = True
except ImportError:
    PICKLESCAN_AVAILABLE = False
    logger.warning("picklescan not available - pickle file security scanning disabled")

try:
    import gguf
    GGUF_AVAILABLE = True
except ImportError:
    GGUF_AVAILABLE = False
    logger.warning("gguf not available - GGUF format support disabled")


def _fast_safetensors_reader(path: str) -> Dict[str, torch.Tensor]:
    """
    Fast safetensors reader that only reads metadata, not tensor data.
    Creates tensors on 'meta' device to avoid memory allocation.
    """
    if not SAFETENSORS_AVAILABLE:
        raise ImportError("safetensors package required for .safetensors files")
    
    checkpoint = {}
    device = torch.device("meta")
    
    with open(path, "rb") as f:
        definition_len = int.from_bytes(f.read(8), "little")
        definition_json = f.read(definition_len)
        definition = json.loads(definition_json)

        if "__metadata__" in definition and definition["__metadata__"].get("format", "pt") not in {
            "pt", "torch", "pytorch"
        }:
            raise Exception("Supported only pytorch safetensors files")
        
        definition.pop("__metadata__", None)

        for key, info in definition.items():
            dtype_map = {
                "I8": torch.int8,
                "I16": torch.int16,
                "I32": torch.int32,
                "I64": torch.int64,
                "F16": torch.float16,
                "F32": torch.float32,
                "F64": torch.float64,
            }
            dtype = dtype_map.get(info["dtype"])
            if dtype is None:
                logger.warning(f"Unknown dtype {info['dtype']} for tensor {key}")
                continue
                
            checkpoint[key] = torch.empty(info["shape"], dtype=dtype, device=device)

    return checkpoint


def read_checkpoint_meta(path: Union[str, Path], scan: bool = True) -> Dict[str, torch.Tensor]:
    """
    Read model checkpoint metadata without loading full tensors into memory.
    
    Args:
        path: Path to model file
        scan: Whether to scan pickle files for malware (requires picklescan)
        
    Returns:
        Dictionary of tensor names to tensor metadata
        
    Raises:
        Exception: If file is corrupted or potentially malicious
        ImportError: If required packages are not available
    """
    path_str = str(path)
    
    if path_str.endswith(".safetensors"):
        if not SAFETENSORS_AVAILABLE:
            raise ImportError("safetensors package required for .safetensors files")
        try:
            checkpoint = _fast_safetensors_reader(path_str)
        except Exception:
            # Fallback to regular safetensors loading
            logger.debug("Fast safetensors reader failed, falling back to regular loader")
            checkpoint = safetensors.torch.load_file(path, device="cpu")
            
    elif path_str.endswith(".gguf"):
        if not GGUF_AVAILABLE:
            raise ImportError("gguf package required for .gguf files")
        # For now, we'll skip GGUF support in the simplified version
        raise NotImplementedError("GGUF support not yet implemented in ModelMan")
        
    else:
        # Handle .ckpt, .pt, .pth, .bin files
        if scan and PICKLESCAN_AVAILABLE:
            try:
                scan_result = pscan.scan_file_path(path)
                if scan_result.infected_files != 0:
                    raise Exception(f"The model at {path} is potentially infected by malware. Aborting import.")
                if scan_result.scan_err:
                    raise Exception(f"Error scanning model at {path} for malware. Aborting import.")
            except Exception as e:
                logger.warning(f"Malware scan failed for {path}: {e}")
        
        # Load checkpoint metadata only
        checkpoint = torch.load(path, map_location=torch.device("meta"))
        
    return checkpoint


def get_model_type_from_checkpoint_keys(checkpoint: Dict[str, torch.Tensor]) -> Optional[str]:
    """
    Analyze checkpoint tensor keys to determine model type.
    
    Args:
        checkpoint: Dictionary of tensor names to tensors
        
    Returns:
        Detected model type or None if unable to determine
    """
    key_names = set(checkpoint.keys())
    
    # Check for FLUX models
    flux_indicators = {"double_blocks.0.img_attn.norm.key_norm.scale", "single_blocks.0.linear1.weight"}
    if any(key in key_names for key in flux_indicators):
        return "flux"
    
    # Check for SD3 models  
    sd3_indicators = {"transformer.x_embedder.proj.weight", "transformer.context_embedder.weight"}
    if any(key in key_names for key in sd3_indicators):
        return "sd3"
    
    # Check for LoRA models
    lora_indicators = {"lora_down", "lora_up", "hada_w1", "hada_w2", "lokr_w1"}
    if any(any(indicator in key for indicator in lora_indicators) for key in key_names):
        return "lora"
    
    # Check for ControlNet models
    controlnet_indicators = {"control_model", "controlnet"}
    if any(any(indicator in key for indicator in controlnet_indicators) for key in key_names):
        return "controlnet"
    
    # Check for VAE models
    vae_indicators = {"decoder.conv_in.weight", "encoder.conv_in.weight"}
    if any(key in key_names for key in vae_indicators):
        return "vae"
    
    # Check for main diffusion models
    unet_indicators = {"model.diffusion_model", "unet"}
    if any(any(indicator in key for indicator in unet_indicators) for key in key_names):
        return "main"
    
    return None


def get_base_model_from_checkpoint_keys(checkpoint: Dict[str, torch.Tensor]) -> Optional[str]:
    """
    Analyze checkpoint to determine base model architecture.
    
    Args:
        checkpoint: Dictionary of tensor names to tensors
        
    Returns:
        Detected base model type or None if unable to determine
    """
    key_names = set(checkpoint.keys())
    
    # Check for FLUX-specific tensors first (most distinctive)
    if any("double_blocks" in key for key in key_names):
        return "flux"
        
    # Check for SD3-specific tensors
    if any("transformer" in key and "x_embedder" in key for key in key_names):
        return "sd-3"
    
    # Look for cross-attention layers to determine context dimension
    cross_attn_keys = [key for key in key_names if ("attn2" in key or "cross_attn" in key) and "to_k" in key and key.endswith(".weight")]
    
    # Also check for text encoder keys that might indicate SDXL
    text_encoder_keys = [key for key in key_names if "text_model" in key and "k_proj" in key and key.endswith(".weight")]
    
    # Try cross-attention keys first
    for key in cross_attn_keys:
        tensor = checkpoint[key]
        if hasattr(tensor, 'shape') and len(tensor.shape) >= 2:
            context_dim = tensor.shape[-1]
            logger.debug(f"Found cross-attention key {key} with context dim {context_dim}")
            
            # Map context dimensions to base models
            if context_dim == 768:
                return "sd-1"
            elif context_dim == 1024:
                return "sd-2"  
            elif context_dim == 2048:
                return "sdxl"
    
    # Try text encoder keys as backup
    for key in text_encoder_keys:
        tensor = checkpoint[key]
        if hasattr(tensor, 'shape') and len(tensor.shape) >= 2:
            # Text encoder embeddings can also indicate model type
            embed_dim = tensor.shape[0] if len(tensor.shape) > 0 else None
            if embed_dim:
                logger.debug(f"Found text encoder key {key} with embed dim {embed_dim}")
                # SDXL has larger text encoder dimensions
                if embed_dim >= 1280:  # CLIP-G indicator
                    return "sdxl"
    
    # Fallback: look for any attention layer and check dimensions
    attn_keys = [key for key in key_names if ("attn" in key and "weight" in key and 
                                             ("to_k" in key or "to_q" in key or "to_v" in key))]
    
    for key in attn_keys[:3]:  # Check first few attention keys
        tensor = checkpoint[key]
        if hasattr(tensor, 'shape') and len(tensor.shape) >= 2:
            # Last dimension often indicates context size
            last_dim = tensor.shape[-1]
            if last_dim == 768:
                return "sd-1"
            elif last_dim == 1024:
                return "sd-2"
            elif last_dim == 2048:
                return "sdxl"
    
    return None


def lora_token_vector_length(checkpoint: Dict[str, torch.Tensor]) -> Optional[int]:
    """
    Given a LoRA checkpoint, return the token vector length.
    
    Args:
        checkpoint: The LoRA checkpoint dictionary
        
    Returns:
        Token vector length or None if unable to determine
    """
    for key, tensor in checkpoint.items():
        if "." not in key:
            continue
            
        model_key, lora_key = key.split(".", 1)
        
        # Check lora/locon format
        if lora_key == "lora_down.weight":
            return tensor.shape[1] if hasattr(tensor, 'shape') and len(tensor.shape) > 1 else None
        
        # Check loha format
        elif lora_key in ["hada_w1_b", "hada_w2_b"]:
            return tensor.shape[1] if hasattr(tensor, 'shape') and len(tensor.shape) > 1 else None
        
        # Check lokr format  
        elif "lokr_" in lora_key and model_key + ".lokr_w1" in checkpoint:
            lokr_w1 = checkpoint[model_key + ".lokr_w1"]
            return lokr_w1.shape[1] if hasattr(lokr_w1, 'shape') and len(lokr_w1.shape) > 1 else None
    
    return None


def get_clip_variant_type(state_dict: Dict[str, torch.Tensor]) -> Optional[str]:
    """
    Determine CLIP variant from state dict.
    
    Args:
        state_dict: Model state dictionary
        
    Returns:
        CLIP variant ("large" or "gigantic") or None
    """
    # Look for text model embeddings to determine variant
    for key in state_dict.keys():
        if "text_model.embeddings.token_embedding.weight" in key:
            tensor = state_dict[key]
            if hasattr(tensor, 'shape') and len(tensor.shape) >= 2:
                embed_dim = tensor.shape[-1]
                if embed_dim == 768:
                    return "large"
                elif embed_dim == 1280:
                    return "gigantic"
    
    return None