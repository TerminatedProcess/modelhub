"""Base result models for ModelMan classification."""
from enum import Enum
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class ClassificationStatus(str, Enum):
    """Classification result status."""
    
    SUCCESS = "success"
    ERROR = "error"
    UNSUPPORTED = "unsupported"


class ModelClassificationResult(BaseModel):
    """Result object returned by model classification."""
    
    # Status and Error Handling
    status: ClassificationStatus = Field(description="Classification result status")
    error_message: Optional[str] = Field(None, description="Error message if status != success")
    error_type: Optional[str] = Field(None, description="Error type for programmatic handling")
    
    # File Information
    file_path: str = Field(description="Path to the analyzed file")
    file_size: int = Field(description="File size in bytes")
    file_name: str = Field(description="Base filename")
    
    # Hashing
    hash_blake3: Optional[str] = Field(None, description="InvokeAI-compatible blake3 hash")
    hash_civitai: Optional[str] = Field(None, description="CivitAI AutoV2 hash")
    hash_sha256: Optional[str] = Field(None, description="Full SHA-256 hash for CivitAI API")
    
    # CivitAI Integration
    civitai_info: Optional[Dict[str, Any]] = Field(None, description="CivitAI model information if found")
    
    # Model Classification (None if status != "success")
    model_type: Optional[str] = Field(None, description="Model type (main, lora, controlnet, etc.)")
    base_model: Optional[str] = Field(None, description="Base model type (sd-1, sdxl, flux, etc.)")
    model_format: Optional[str] = Field(None, description="Model format (checkpoint, diffusers, etc.)")
    model_variant: Optional[str] = Field(None, description="Model variant (normal, inpaint, depth, etc.)")
    model_style: Optional[str] = Field(None, description="Model style/aesthetic (realistic, anime, illustrious, etc.)")
    
    # Advanced Classification Details
    prediction_type: Optional[str] = Field(None, description="Scheduler prediction type")
    config_path: Optional[str] = Field(None, description="Path to model config file")
    submodels: Optional[Dict[str, Any]] = Field(None, description="Submodel definitions for composite models")
    
    # Metadata
    description: Optional[str] = Field(None, description="Human-readable model description")
    key: Optional[str] = Field(None, description="Unique identifier (UUID)")
    
    # Raw InvokeAI Config (for advanced users)
    raw_config: Optional[Dict[str, Any]] = Field(None, description="Complete InvokeAI configuration object")
    
    class Config:
        """Pydantic configuration."""
        use_enum_values = True
        arbitrary_types_allowed = True