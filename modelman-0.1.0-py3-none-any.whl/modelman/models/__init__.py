"""Model definitions for ModelMan."""
from .base import ClassificationStatus, ModelClassificationResult
from .taxonomy import (
    BaseModelType,
    ModelType,
    ModelFormat,
    ModelVariantType,
    ModelStyleType,
    SchedulerPredictionType,
    ModelSourceType,
    SubModelType,
    ClipVariantType,
    FluxLoRAFormat,
    ModelRepoVariant,
    AnyVariant,
)

__all__ = [
    # Result models
    "ClassificationStatus",
    "ModelClassificationResult",
    # Taxonomy
    "BaseModelType",
    "ModelType", 
    "ModelFormat",
    "ModelVariantType",
    "ModelStyleType",
    "SchedulerPredictionType",
    "ModelSourceType",
    "SubModelType",
    "ClipVariantType", 
    "FluxLoRAFormat",
    "ModelRepoVariant",
    "AnyVariant",
]