"""Custom exceptions for ModelMan."""


class ModelManException(Exception):
    """Base exception for ModelMan."""
    pass


class UnsupportedFormatError(ModelManException):
    """Raised when a file format is not supported."""
    pass


class FileAccessError(ModelManException):
    """Raised when a file cannot be accessed."""
    pass


class CorruptedModelError(ModelManException):
    """Raised when a model file is corrupted or invalid."""
    pass


class ClassificationError(ModelManException):
    """Raised when model classification fails."""
    pass


class InvalidModelConfigException(ModelManException):
    """Raised when model configuration is invalid (InvokeAI compatibility)."""
    pass